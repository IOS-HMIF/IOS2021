import SweetAlert from './SweetAlert.js'

const Swal = SweetAlert
Swal.default = Swal

export default Swal
